﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;


class Money : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI money;

    private long currentMoney = 0;

    void Start()
    {
        UpdateMoneyDisplay();
    }

    public void IncreaseMoney(long value)
    {
        currentMoney += value;
        UpdateMoneyDisplay();
    }

    public void DecreaseMoney(long value)
    {
        currentMoney -= value; // уменьшаем значение
        UpdateMoneyDisplay();
    }

    void UpdateMoneyDisplay()
    {
        money.text = currentMoney.ToString();
    }

}

