﻿using Assets.Scripts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;


class SellOneProduct : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI currentCoins;
    [SerializeField] private TextMeshProUGUI currentQuality;
    [SerializeField] private Product product;
    private readonly int quantityForSale = 1;

    private void Start()
    {
        GetComponent<Button>().onClick.AddListener(OnClick);
    }

    private void OnClick()
    {
       if(product.quantity >= quantityForSale)
        {
            product.quantity -= quantityForSale;
            long coins = long.Parse(currentCoins.text);
            coins += product.price;
            currentCoins.text = coins.ToString();

            currentQuality.text = "Quality: " + product.quantity.ToString();
        }
    }
}
