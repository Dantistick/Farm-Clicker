﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

class SellAllProduct : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI currentCoins;
    [SerializeField] private TextMeshProUGUI currentQuality;
    [SerializeField] private Product product;

    private void Start()
    {
        GetComponent<Button>().onClick.AddListener(OnClick);
    }

    private void OnClick()
    {
        long coins = long.Parse(currentCoins.text);
        coins += product.price * product.quantity;
        currentCoins.text = coins.ToString();

        product.quantity = 0;

        currentQuality.text = "Quality: " + product.quantity.ToString();

    }
}

