﻿using Assets.Scripts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;


class ProductDelivery : MonoBehaviour
{
    [SerializeField] private Product product;
    [SerializeField] private TextMeshProUGUI quality;

    private void Start()
    {
        GetComponent<Button>().onClick.AddListener(OnClick);
    }

    private void OnClick()
    {
        InvokeRepeating("AddIncome", 0f, 5f);
    }

    private void AddIncome()
    {
        product.quantity += product.upgradeQuality;
        quality.text = "Quality: " + product.quantity; 
    }
}

