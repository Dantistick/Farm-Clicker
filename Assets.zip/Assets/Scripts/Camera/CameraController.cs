using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public float speed = 1.0f;

    private Vector3 dragStartPosition;
    private bool isDragging;
    private float startYPosition;

    void Start()
    {
        startYPosition = transform.position.y;
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            dragStartPosition = Input.mousePosition;
            isDragging = true;
        }

        if (Input.GetMouseButton(0) && isDragging)
        {
            Vector3 dragDelta = Input.mousePosition - dragStartPosition;
            float currentYPosition = transform.position.y;
            transform.position = new Vector3(
                transform.position.x,
                startYPosition,
                transform.position.z
            );
            transform.Translate(-dragDelta * Time.deltaTime * speed);
            transform.position = new Vector3(
                transform.position.x,
                currentYPosition,
                transform.position.z
            );
            dragStartPosition = Input.mousePosition;
        }

        if (Input.GetMouseButtonUp(0))
        {
            isDragging = false;
        }
    }
}
