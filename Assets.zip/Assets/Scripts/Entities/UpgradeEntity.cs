﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assets.Scripts;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Assets.Scripts
{
    class UpgradeEntity : MonoBehaviour
    {
        public TextMeshProUGUI description;
        public TextMeshProUGUI profit;
        public TextMeshProUGUI currentPriceToUpgrade;
    }
}
