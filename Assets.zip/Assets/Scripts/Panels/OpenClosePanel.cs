using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class OpenClostPanel : MonoBehaviour
{
    [SerializeField] private GameObject panel;
    [SerializeField] private Button toggleButton;

    private bool isPanelActive = false;

    private void Start()
    {
        toggleButton.onClick.AddListener(TogglePanel);
    }

    private void TogglePanel()
    {
        isPanelActive = !isPanelActive;
        panel.SetActive(isPanelActive);
    }
}
