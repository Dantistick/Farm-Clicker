using Assets.Scripts;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class BuildBuilding : MonoBehaviour
{
    [SerializeField] private GameObject needToBuild;

    [SerializeField] private Building building;
    [SerializeField] private BuildEntity buildEntity;
    [SerializeField] private TextMeshProUGUI currentCoins;

    [SerializeField] private GameObject upgradePanel;
    [SerializeField] private GameObject icon;

    private void Start()
    {
        GetComponent<Button>().onClick.AddListener(OnClick);
    }

    private void OnClick()
    {
        long priceToBuyBuilding = building.priceToBuy;
        long coins = long.Parse(currentCoins.text);
        if (coins >= priceToBuyBuilding)
        {
            coins -= priceToBuyBuilding;
            currentCoins.text = coins.ToString();

            needToBuild.SetActive(true);
            InvokeRepeating("AddIncome", 0f, 1f);
            gameObject.SetActive(false);
            icon.SetActive(true);
            
            upgradePanel.SetActive(true);
            Destroy(buildEntity.profit);
            Destroy(buildEntity.currentPriceToBuy);
        }

    }

    private void AddIncome()
    {
        long coins = long.Parse(currentCoins.text);
        coins += building.profitPerSecond;
        currentCoins.text = coins.ToString();
    }
}
