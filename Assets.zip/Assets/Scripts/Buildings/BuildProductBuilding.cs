﻿using Assets.Scripts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;


class BuildProductBuilding : MonoBehaviour
{
    [SerializeField] private GameObject needToBuild;

    [SerializeField] private Building building;
    [SerializeField] private BuildEntity buildEntity;
    [SerializeField] private TextMeshProUGUI currentCoins;

    [SerializeField] private GameObject upgradePanel;
    [SerializeField] private GameObject icon;

    private void Start()
    {
        GetComponent<Button>().onClick.AddListener(OnClick);
    }

    private void OnClick()
    {
        long priceToBuyBuilding = building.priceToBuy;
        long coins = long.Parse(currentCoins.text);
        if (coins >= priceToBuyBuilding)
        {
            coins -= priceToBuyBuilding;
            currentCoins.text = coins.ToString();

            needToBuild.SetActive(true);
            
            gameObject.SetActive(false);
            icon.SetActive(true);

            Destroy(buildEntity.profit);
            Destroy(buildEntity.currentPriceToBuy);
            upgradePanel.SetActive(true);
        }

    }
}

