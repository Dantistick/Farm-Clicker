﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;

namespace Assets.Scripts
{
    class Building : MonoBehaviour
    {
        public int currentLevel = 1;
        public long priceToBuy = 100;
        public long currentPriceToUpgrade = 100;
        public long profitPerSecondUpgrade = 1;
        public long profitPerSecond = 1;
        public new string name;
    }
}
