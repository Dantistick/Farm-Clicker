﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Assets.Scripts
{
    class UpgradeBuild : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI currentCoins;
        [SerializeField] private Building building;
        [SerializeField] private UpgradeEntity upgradeEntity;

        private void Start()
        {
            GetComponent<Button>().onClick.AddListener(OnClick);
        }

        private void OnClick()
        {
            if (IsHaveCoins())
            {
                building.currentLevel++;

                long currentPriceToUpgrade = long.Parse(upgradeEntity.currentPriceToUpgrade.text);
                long coins = long.Parse(currentCoins.text);
                coins -= currentPriceToUpgrade;
                currentCoins.text = coins.ToString();

                building.currentPriceToUpgrade = (long)(currentPriceToUpgrade * 1.1);
                building.profitPerSecond += building.profitPerSecondUpgrade;

                upgradeEntity.description.text = building.name + " lvl " + building.currentLevel;
                upgradeEntity.currentPriceToUpgrade.text = building.currentPriceToUpgrade.ToString();
                upgradeEntity.profit.text = building.profitPerSecond.ToString();
            }
        }

        private bool IsHaveCoins()
        {
            return long.Parse(currentCoins.text) >= long.Parse(upgradeEntity.currentPriceToUpgrade.text);
        }
    }
}
