using Assets.Scripts;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UpgradeBarn : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI currentCoins;
    [SerializeField] private Barn barn;
    [SerializeField] private UpgradeEntity upgradeEntity;

    private void Start()
    {
        GetComponent<Button>().onClick.AddListener(OnClick);
    }

    private void OnClick()
    {
        if (IsMaxLevel() && IsHaveCoins())
        {
            barn.currentLevel++;
            switch (barn.currentLevel)
            {
                case 2:
                    {
                        BarnLevelTwo();
                        break;
                    }
                case 3:
                    {
                        BarnLevelThree();
                        break;
                    }
            }

        }

    }

    private void BarnLevelTwo()
    {
        long currentPriceToUpgrade = long.Parse(upgradeEntity.currentPriceToUpgrade.text);

        long coins = long.Parse(currentCoins.text);
        coins -= currentPriceToUpgrade;
        currentCoins.text = coins.ToString();

        barn.costPerClick = 10;
        upgradeEntity.description.text = "Barn lvl " + barn.currentLevel;
        currentPriceToUpgrade = 10000;
        upgradeEntity.currentPriceToUpgrade.text = currentPriceToUpgrade.ToString();
        upgradeEntity.profit.text = barn.costPerClick.ToString();
    }

    private void BarnLevelThree()
    {
        long currentPriceToUpgrade = long.Parse(upgradeEntity.currentPriceToUpgrade.text);

        long coins = long.Parse(currentCoins.text);
        coins -= currentPriceToUpgrade;
        currentCoins.text = coins.ToString();

        barn.costPerClick = 100;
        upgradeEntity.description.text = "Max Level!";
        upgradeEntity.profit.text = barn.costPerClick.ToString();
        Destroy(upgradeEntity.currentPriceToUpgrade);
        Destroy(gameObject);
    }

    private bool IsMaxLevel()
    {
        return barn.currentLevel <= barn.maxLevel;
    }

    private bool IsHaveCoins()
    {
        return long.Parse(currentCoins.text) >= long.Parse(upgradeEntity.currentPriceToUpgrade.text);
    }
}
