using Assets.Scripts;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ClickBarn : MonoBehaviour, IPointerClickHandler
{
    [SerializeField] private TextMeshProUGUI currentCoins;
    [SerializeField] private Barn barn;

    public void OnPointerClick(PointerEventData eventData)
    {
        long currentQuality = long.Parse(currentCoins.text);
        currentQuality += barn.costPerClick;
        currentCoins.text = currentQuality.ToString();
    }
}
