﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;


public class Barn : MonoBehaviour
{
    public readonly int maxLevel = 3;
    public int currentLevel = 1;
    public int costPerClick = 1;
}

